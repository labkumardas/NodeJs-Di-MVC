import fs from 'fs';

const handleUploads = async (req, res, next) => {
  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).json({ error: 'No files were uploaded.' });
  }

  const files = req.files;
  const errors = [];
  const uploadFolder = './public/uploads'; // Change this to your desired folder path
  const uploadedFiles = [];

  // Create the "uploads" folder if it doesn't exist
  if (!fs.existsSync(uploadFolder)) {
    fs.mkdirSync(uploadFolder);
  }

  // Function to move a file and return a promise
  const moveFile = (file, newPath) => {
    return new Promise((resolve, reject) => {
      file.mv(newPath, (err) => {
        if (err) {
          reject(err);
        } else {
          resolve({
            name: file.name,
            size: file.size,
            mimetype: file.mimetype,
            path: newPath,
            url: `/uploads/${file.name}`, // Construct the URL
          });
        }
      });
    });
  };

  // Use Promise.all to wait for all file movements
  try {
    const movePromises = files.image.map((file) => {
      const allowedTypes = ['image/jpeg', 'image/png'];
      const maxSize = 5 * 1024 * 1024; // 5MB

      if (!allowedTypes.includes(file.mimetype)) {
        errors.push(`Invalid file type: ${file.name}`);
        return Promise.resolve();
      }

      if (file.size > maxSize) {
        errors.push(`File too large: ${file.name}`);
        return Promise.resolve();
      }

      const newPath = `${uploadFolder}/${file.name}`;
      return moveFile(file, newPath);
    });

    const results = await Promise.all(movePromises);

    // Filter out any undefined results (files that didn't meet criteria)
    const validResults = results.filter((result) => result);

    uploadedFiles.push(...validResults);
    req.uploadedFiles = uploadedFiles;
    next();
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error moving files to destination.' });
  }
};

export default handleUploads;
