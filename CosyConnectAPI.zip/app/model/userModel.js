"use strict";
import mongoose from 'mongoose';
const userSchema = new mongoose.Schema({
  first_name: { type: String, required: true, trim: true },
  last_name: { type: String, required: true, trim: true },
  username: { type: String, required: true, trim: true, unique: true },
  phone: { type: Number, required: true, trim: true, unique: true },
  email: { type: String, required: true, trim: true, unique: true },
  password: { type: String, required: true, trim: true },
  dob: { type: String, required: true, trim: true },
  city: { type: String,  trim: true },
  pin: { type: String,  trim: true },
  role_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Roles', required: true, unique: false, },
  isActive: { type: Boolean, required: true, trim: true },
  isBlocked: { type: Boolean, required: true, trim: true },
  createdAt: { type: Date, default: Date.now }, 
});
userSchema.index({ phone: 1, email: 1 , username:1 ,password:1 });
const userModel = mongoose.model('users', userSchema);
export default userModel;
