"use strict";
import mongoose from 'mongoose';
const userRevieSchema = new mongoose.Schema({
  reviewBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Users', required: true },
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Users', required: true },
  description: { type: String,   trim: true  },
  rating: { type: Number, required: true, trim: true  },
  createdAt: { type: Date, default: Date.now }, 
});
userRevieSchema.index({ reviewBy: 1, reviewFor: 1 , rating:1 });
const userReviewModel = mongoose.model('userreviews', userRevieSchema);
export default userReviewModel;
