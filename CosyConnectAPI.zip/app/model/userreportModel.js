"use strict";
import mongoose from 'mongoose';
const userreportMetaSchema = new mongoose.Schema({
  profile_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Users', required: true },
  report_type: {
    type: String,
    enum: ['block','inappropriate_behaviour','spamming', 'hate_speech', 'nudity','identity_theft'],
    default: 'block',
  },
  description : {type: String , trim: true },
  reportBy : { type: mongoose.Schema.Types.ObjectId, ref: 'Users', required: true },
  createdAt: { type: Date, default: Date.now }, 
});
userreportMetaSchema.index({ user_id: 1 });
const userreportModel = mongoose.model('usermetas', userreportMetaSchema);
export default userreportModel;
 