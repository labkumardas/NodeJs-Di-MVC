import authRoutes from './auth-route.js';
import registrationRoutes from './registration-route.js';
import globalRoutes from './global-route.js';

const setupRoutes = (app) => {
  // Set up all your routes here
  registrationRoutes(app);
  authRoutes(app);
  globalRoutes(app);
};

export default setupRoutes;