"use strict";
import configApi from '../../config/configApi.js';
import handleUploads from '../helper/fileUploadMiddleware.js';  // Import handleUploads first
import registrationController from '../src/controller/registration/registrationController.js';
import RegistrationValidation from '../middleware/validation/registrationValidation.js';
//
const { apiPrefix } = configApi;
export default function setupRegistrationRoutes(app) {
app.post(`${apiPrefix}/check/user/phone`, registrationController.checkUserPhone);
app.post(`${apiPrefix}/check/email`, registrationController.checkUserEmail);
app.post(`${apiPrefix}/check/username`, registrationController.checkUserName);
//app.post(`${apiPrefix}/create/user/step1`,RegistrationValidation.registrationStep1 , registrationController.userRegistrationStep1);
//app.post(`${apiPrefix}/create/user/step2`, registrationController.userRegistrationStep2);
//app.post(`${apiPrefix}/upload/user/image`, handleUploads, registrationController.userImageUpload);
app.post(`${apiPrefix}/create/user`,RegistrationValidation.registrationStep1 , handleUploads , registrationController.userDataCreate);

}
