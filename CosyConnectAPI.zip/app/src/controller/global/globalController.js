// controller/global/globalController.js
"use strict";
import container from '../../container/container.js';
import responseStatus from '../../../util/responseStatus.js';

class GlobalController {
  constructor() {
    this.roleService = container.resolve('roleService');
  }

  viewRole = async (req, res) => {
    try {
      const result = await this.roleService.viewRoleList(req.body);
      const { code, message } = responseStatus.getStatus('OK');
      return res.status(code).send({ status: code, message,  data: { result } });

     } catch (error) {
      const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
      return res.status(code).send({ status: code, message, error: error.message });
    }
  }
  

}
export default new GlobalController();
