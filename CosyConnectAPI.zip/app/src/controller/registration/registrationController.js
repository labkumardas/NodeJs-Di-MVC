"use strict";
import container from '../../container/container.js';
import responseStatus from '../../../util/responseStatus.js';

class registrationController {
  constructor() {
    this.userService = container.resolve('userService');
  }

  checkUserPhone = async (req, res) => {
    try {

      const result = await this.userService.isPhoneExists(req.body.phone);
      if (result) {
        const { code, message } = responseStatus.getStatus('EXISTING_PHONE_NUMBER');
        return res.status(code).send({ status: code, message, data: { isPhoneExists: result } });
      }
      else {
        const { code, message } = responseStatus.getStatus('OK');
        return res.status(code).send({ status: code, message, data: { isPhoneExists: result } });
      }

    } catch (error) {
      const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
      console.log(error);
      return res.status(code).send({ status: code, message, error: error.message });
    }
  }

  checkUserEmail = async (req, res) => {
    try {

      const result = await this.userService.isEmailExists(req.body.email);
      if (result) {
        const { code, message } = responseStatus.getStatus('EXISTING_EMAIL');
        return res.status(code).send({ status: code, message, data: { isEmailExists: result } });
      }
      else {
        const { code, message } = responseStatus.getStatus('OK');
        return res.status(code).send({ status: code, message, data: { isEmailExists: result } });
      }

    } catch (error) {
      const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
      console.log(error);
      return res.status(code).send({ status: code, message, error: error.message });
    }
  }

  checkUserName = async (req, res) => {
    try {
      const userName = req.body.username.toLowerCase();
      const result = await this.userService.isUsernameExists(userName);
      if (result) {
        const { code, message } = responseStatus.getStatus('EXISTING_USERNAME');
        return res.status(code).send({ status: code, message, data: { isUsernameExists: result } });
      }
      else {
        const { code, message } = responseStatus.getStatus('OK');
        return res.status(code).send({ status: code, message, data: { isUsernameExists: result } });
      }

    } catch (error) {
      const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
      console.log(error);
      return res.status(code).send({ status: code, message, error: error.message });
    }
  }
  userDataCreate = async (req,res)=>{
     try {
      const isEmailExists = await this.userService.isEmailExists(req.body.email);
      if (isEmailExists) {
        const { code, message } = responseStatus.getStatus('EXISTING_EMAIL');
        return res.status(code).send({ status: code, message, data: { isEmailExists } });
      }
    
      // Check if phone exists
      const isPhoneExists = await this.userService.isPhoneExists(req.body.phone);
      if (isPhoneExists) {
        const { code, message } = responseStatus.getStatus('EXISTING_PHONE_NUMBER');
        return res.status(code).send({ status: code, message, data: { isPhoneExists } });
      }
    
      // Check if username exists
      const userName = req.body.username.toLowerCase();
      const isUsernameExists = await this.userService.isUsernameExists(userName);
      if (isUsernameExists) {
        const { code, message } = responseStatus.getStatus('EXISTING_USERNAME');
        return res.status(code).send({ status: code, message, data: { isUsernameExists } });
      }
      let updateImage;
      const createUserRequiredFild = await this.userService.createUser(req.body);
      const lastId =  createUserRequiredFild._id;
      const createUser2 = await this.userService.updateUserSetting( req.body, lastId  );
      console.log(req.uploadedFiles);
      if(req.uploadedFiles){
        updateImage = await this.userService.updateUserImage(req.uploadedFiles, lastId);
      }
     
      const { code, message   } = responseStatus.getStatus('CREATED','User registration successful.');

      return res.status(code).send({ status: code, message,  data: { user_id: lastId , image: updateImage } });

     } catch (error) {
      const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
      return res.status(code).send({ status: code, message, error: error.message });
     }
  }

  // userRegistrationStep1 = async (req, res) => {
  //   try {
  //     // Check if email exists
  //     const isEmailExists = await this.userService.isEmailExists(req.body.email);
  //     if (isEmailExists) {
  //       const { code, message } = responseStatus.getStatus('EXISTING_EMAIL');
  //       return res.status(code).send({ status: code, message, data: { isEmailExists } });
  //     }
    
  //     // Check if phone exists
  //     const isPhoneExists = await this.userService.isPhoneExists(req.body.phone);
  //     if (isPhoneExists) {
  //       const { code, message } = responseStatus.getStatus('EXISTING_PHONE_NUMBER');
  //       return res.status(code).send({ status: code, message, data: { isPhoneExists } });
  //     }
    
  //     // Check if username exists
  //     const userName = req.body.username.toLowerCase();
  //     const isUsernameExists = await this.userService.isUsernameExists(userName);
  //     if (isUsernameExists) {
  //       const { code, message } = responseStatus.getStatus('EXISTING_USERNAME');
  //       return res.status(code).send({ status: code, message, data: { isUsernameExists } });
  //     }
    
  //     // Create user
  //     const result = await this.userService.createUser(req.body);
  //     const { code, message } = responseStatus.getStatus('CREATED');
  //     return res.status(code).send({ status: code, message, data: { id: result._id } });
    
  //   } catch (error) {
  //     const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
  //     return res.status(code).send({ status: code, message, error: error.message });
  //   }
    
  // }

  // userRegistrationStep2 = async (req, res) => {
  //   try {
  //     const result = await this.userService.updateUserSetting(req.body);
  //     const { code, message } = responseStatus.getStatus('CREATED');
  //     return res.status(code).send({ status: code, message, data: { id: result._id } });
  //   } catch (error) {
  //     const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
  //     console.log(error);
  //     return res.status(code).send({ status: code, message, error: error.message });
  //   }
  // }

  // userImageUpload = async (req, res) => {
  //   try {
  //     const userId = req.body.user_id;
  //     const result = await this.userService.updateUserImage(req.uploadedFiles, userId);
  //     const { code, message } = responseStatus.getStatus('CREATED');
  //     return res.status(code).send({ status: code, message, data: { result } });
  //   } catch (error) {
  //     const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
  //     console.log(error);
  //     return res.status(code).send({ status: code, message, error: error.message });
  //   }
  // }

}

export default new registrationController();
