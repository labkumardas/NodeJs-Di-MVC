// controller/global/globalController.js
"use strict";
import container from '../../container/container.js';
import responseStatus from '../../../util/responseStatus.js';
//
 class userController {
  constructor() {
    this.userService = container.resolve('userService');
    this.notificationService = container.resolve('notificationService');

   }

  profileList = async (req, res) => {
    try {
        const data = await this.userService.getAllProfile(req);
        const { code, message } = responseStatus.getStatus('OK');
        return res.status(code).send({ status: code, message, data: data });
    } catch (error) {
        const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
        return res.status(code).send({ status: code, message, error: error.message });
    }
  }

  getProfileMeta = async (req,res)=>{
     try {
      const data = await this.userService.getProfileMetaData(req.body.profileId);
      const { code, message } = responseStatus.getStatus('OK');
      return res.status(code).send({ status: code, message, data: data });
     } catch (error) {
      const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
      return res.status(code).send({ status: code, message, error: error.message });
     }
  }

  blockProfile = async (req,res)=>{
    try {
     const data = await this.userService.createBlockProfile(req.body);
     const { code, message } = responseStatus.getStatus('OK');
     return res.status(code).send({ status: code, message, data: data });
    } catch (error) {
     const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
     return res.status(code).send({ status: code, message, error: error.message });
    }
  }

  sendRequest= async (req,res)=>{
    try {
     const data = await this.notificationService.sendRequestToUser(req.body);
     const { code, message } = responseStatus.getStatus('OK');
     return res.status(code).send({ status: code, message, data: data });
    } catch (error) {
     const { code, message } = responseStatus.getStatus('INTERNAL_SERVER_ERROR');
     return res.status(code).send({ status: code, message, error: error.message });
    }
  }
  
 

}
export default new userController();
