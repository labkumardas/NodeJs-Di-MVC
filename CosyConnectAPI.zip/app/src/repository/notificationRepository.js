// service/global/globalService.js
"use strict";
import notificationModel from '../../model/notificationModel.js';
import friendRequestModel from '../../model/friendRequestModel.js';

class notificationRepository {
  constructor() {
  }

  async storeFriendRequst(friendRequestData, notificationData) {
    try {
      const [insertReq, insertNoti] = await Promise.all([
        friendRequestModel.create(friendRequestData),
        notificationModel.create(notificationData),
      ]);
     return insertNoti;
    } catch (error) {
      throw new Error(error);
    }
  }


}

export default new notificationRepository();