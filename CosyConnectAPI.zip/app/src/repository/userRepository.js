// service/global/globalService.js
"use strict";
import userModel from '../../model/userModel.js';
import profileImageModel from '../../model/profileImageModel.js';
import settingModel from '../../model/settingModel.js';
import userreportModel from '../../model/userreportModel.js';


class userService {
  constructor() {

  }
  async findPhone(phone) {
    const existingUser = await userModel.findOne({ phone });
    return !!existingUser;
  }

  async findEmail(email) {
    const existingUser = await userModel.findOne({ email });
    return !!existingUser;
  }

  async findUserName(username) {
    const existingUser = await userModel.findOne({ username });
    return !!existingUser;
  }

  async insertUser(userData) {
    try {
      return userModel.create(userData);
    }
    catch (error) {
      throw new Error(error)
    }
  }

  async isUserSettingExists(user_id) {
    const existingSetting = await settingModel.findOne({ user_id });
    return !!existingSetting;
  }

  async findAndUpdate(filter, updateData) {
    try {
      const result = await settingModel.findOneAndUpdate(filter, updateData, { new: true });
      return result;
    } catch (error) {
      throw new Error(error);
    }
  }

  async insertSettingData(data) {
    try {
      return await settingModel.create(data)
    } catch (error) {
      throw new Error(error);
    }
  }

  async uploadImage(insertArry) {
    try {
      const insert = await profileImageModel.create(insertArry);
      return insert;

    } catch (error) {
      throw new Error(error);
    }
  }

  async getProfileList() {
    try {
      const result = await userModel.aggregate([
        {
          $match: { isBlocked: false, isActive: true }
        },
        {
          $lookup: {
            from: 'userreviews',
            localField: '_id',
            foreignField: 'user_id',
            as: 'userReviews'
          }
        },

        {
          $lookup: {
            from: 'settings',
            localField: '_id',
            foreignField: 'user_id',
            as: 'userSetting'
          }
        },
        {
          $lookup: {
            from: 'profileimages',
            localField: '_id',
            foreignField: 'user_id',
            as: 'profileImages'
          }
        },
        {
          $lookup: {
            from: 'roles',
            localField: 'role_id',
            foreignField: '_id',
            as: 'userRole'
          }
        },
        {
          $project: {
            first_name: 1,
            last_name: 1,
            dob: 1,
            city: 1,
            userRole: { role: 1 },
            userReviews: {
              reviewBy: 1,
              description: 1,
              rating: 1
            },
            userSetting: {
              about_user: 1
            },
            profileImages: {
              profile_image: 1
            }
          }
        }
      ]);
      return result;
    } catch (error) {
      console.error("getProfileList", error)
      throw new Error(error);
    }
  }
  async findUserMeta (profileId){
    try {
      return await settingModel.findOne({user_id:profileId}).select('-__v'); 
    } catch (error) {
      throw new Error(error);
    }
    
  }
  async insertProfileBlockData (data){
    try {
      return await userreportModel.create(data); 
    } catch (error) {
      throw new Error(error);
    }
  }
  async getUserIdByUsername(id) {
    try {
        const user =await userModel.findById(id).select('id username').exec();
       return user ? user.username : null;
    } catch (error) {
      throw new Error(error);
    }
  }

}

export default new userService();