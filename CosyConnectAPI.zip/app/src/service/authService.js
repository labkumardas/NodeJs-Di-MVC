"use strict";
import globalHelper from '../../helper/globalHelper.js';
import authRepository from '../repository/authRepository.js';
import moment from 'moment';
class authService {
    constructor() {
      this.helper = new globalHelper();
     }
    async loginWithUsername(username, password) {
        try {
            const userName = username.toLowerCase();
            const getData = await  authRepository.userLogin(userName,password);
            return getData;
        } 
        catch (error) {
          throw new Error(error)
        }
    }

    async loginWithPhoneNumber(phoneNumber) {
      try {
           
          
      } 
      catch (error) {
        throw new Error(error)
      }
    }

    async saveLoginHistory(data) {
      try {
        const userData ={
          user_id : data.user.userId,
          userToken : data.accessToken,
          deviceType : null,
          deviceId : null,
          isActive : true,
          isBlacklist : false,
          lastLogin : moment().format('DD-MM-YYYY hh:mm:ss A'),
        }
        const insert = await  authRepository.createLoginHistory(userData);
        return  insert;
           
         } 
      catch (error) {
        throw new Error(error)
      }
    }
    async logOut(userId, authHeader) {
        const token = authHeader.substring(7);
        const newData ={
            isActive:false,
            isBlacklist:true,
        }
      try {
        const result = await  authRepository.updateLoginHistory(userId, token,newData);
        return result;
        }   
      catch (error) {
        throw new Error(error)
      }
    }
    async checkBlackListToken(authHeader) {
      const token = authHeader.substring(7);
       try {
         
         return await authRepository.checkToken(token);
        
        }   
      catch (error) {
        throw new Error(error)
      }
    }
    

}

export default new authService();