"use strict";
import globalHelper from '../../helper/globalHelper.js';
import notificationRepository from '../repository/notificationRepository.js';
import userRepository from '../repository/userRepository.js';
import notificationText from '../../util/notificationText.js';

class notificationService {
    constructor() {
        this.helper = new globalHelper();
    }

    async sendRequestToUser(data) {
        const senderIdName = await userRepository.getUserIdByUsername(data.senderId);
        const notificationTextInstance = new notificationText();
        const friendRequestData = {
            senderId: data.senderId,
            receiverId: data.receiverId,
            status: 'pending',
        };
        const notificationData = {
            title: notificationTextInstance.requestSendTitle(senderIdName),
            content: notificationTextInstance.requestSendBody(senderIdName),
            sendBy: data.senderId,
            receiveBy: data.receiverId,
            isRead: false,
        }
        console.log(friendRequestData, notificationData);
        try {
            return await notificationRepository.storeFriendRequst(friendRequestData, notificationData);
        } catch (error) {
            throw new Error(error);
        }
    }


}

export default new notificationService();