// service/global/globalService.js
"use strict";
import bcrypt from 'bcryptjs';
import globalHelper from '../../helper/globalHelper.js';
import userRepository from '../repository/userRepository.js';

class userService {
    constructor() {
      this.helper = new globalHelper();
    }

    async isPhoneExists(phone) {
        const existingUser = await userRepository.findPhone(phone);
        return !!existingUser;
    }

    async isEmailExists(email) {
        const existingUser = await userRepository.findEmail(email);
        return !!existingUser;
    }

    async isUsernameExists(username) {
        const existingUser = await userRepository.findUserName(username);
        return !!existingUser;
    }

    async createUser(data) {
        const userData = {
            role_id:data.role_id,
            first_name : data.first_name,
            last_name : data.last_name,
            username :data.username.toLowerCase(),
            phone : data.phone,
            email : data.email,
            password :bcrypt.hashSync(data.password, 8),
            dob : data.dob,
            isActive: true,
            isBlocked: false
        }
        try {
          return await userRepository.insertUser(userData);
        } 
        catch (error) {
            throw new Error(error)
        }
    }

    async updateUserSetting(data,lastId) {
          const filter = { user_id: lastId };
          const updateData = {
              user_id : lastId,
              user_interest : data.user_interest,
              age_from : data.age_from,
              age_to : data.age_to,
              profile_distance : data.profile_distance,
              budget : data.budget,
              user_notification : true,
              user_fingerprint : false,
              about_user : data.about_user
          };
        try {
            if (await userRepository.isUserSettingExists(lastId)) {
              return await userRepository.findAndUpdate(filter, updateData);
            } 
            else {
              return await userRepository.insertSettingData(updateData);
            }
        } catch (error) {
            throw new Error(error);
        }
    }

    async updateUserImage(data,userid) {
        const insertArry=[];
            data.forEach(element => {
                insertArry.push({
                    user_id : userid,
                    profile_image : element.url,
                })
            });
          try {
            return await userRepository.uploadImage(insertArry);
        } catch (error) {
            throw new Error(error);
        }
    }

    async getProfileMetaData(profileId) {
     
        try {
          return await userRepository.findUserMeta(profileId);
        } 
        catch (error) {
            throw new Error(error)
        }
    }
    
    async createBlockProfile (data){
        try {
            const insertData = {
                profile_id:data.profile_id,
                report_type:data.report_type,
                description:data.description,
                reportBy:data.reportBy
            }
            return await userRepository.insertProfileBlockData(insertData);
           } catch (error) {
               throw new Error(error);
           } 
    }
    
    async getAllProfile() {
        try {
         return await userRepository.getProfileList();
        } catch (error) {
            throw new Error(error);
        }
    }
    

}

export default new userService();