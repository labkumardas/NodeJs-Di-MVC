export default class notificationText {
    requestSendTitle(name) {
      const senderUsername = name || 'User';
      return `You received a friend request from ${senderUsername}.`;
    }
    requestSendBody(name) {
      return `Hey ${name}, you have a new friend request! Check it out and connect.`;   
    }
    
  }
  