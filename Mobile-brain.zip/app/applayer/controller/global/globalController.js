// controller/global/globalController.js
"use strict";
import container from '../../di/container.js';
class GlobalController {
  constructor() {
   this.globalService = container.resolve('globalService');
  }

  getTeam = async (req, res) => {
    try {
      const result = await this.globalService.viewTeam(req);
        return res.status(200).send(result);

    } catch (error) {
       res.status(500).send(error.message);
    }
  }
}
export default new GlobalController();
