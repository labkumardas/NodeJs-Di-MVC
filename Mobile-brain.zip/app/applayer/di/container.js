// container.js
"use strict";
import serviceLocator from './serviceLocator.js';
import globalService from '../service/globalService.js';
import globalHelper from './../../helper/globalHelper.js';
import redisServerHelper from '../redis/redisServerHelper.js';

 serviceLocator.register('globalService', globalService);
 serviceLocator.register('globalHelper', globalHelper);
 serviceLocator.register('redisServerHelper', redisServerHelper);

 
export default serviceLocator;