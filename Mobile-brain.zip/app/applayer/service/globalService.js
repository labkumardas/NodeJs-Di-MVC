// service/global/globalService.js
"use strict";
import globalHelper from '../../helper/globalHelper.js';
import apiUrlConfig from '../../../config/configApi.json' assert { type: 'json' };
import leagueModel from '../../model/league.js';
 
class GlobalService {
  constructor() {
    this.helper = new globalHelper();
 
  }
  async viewTeam(req) {
    const teamData = await this.helper.fetchData(apiUrlConfig.PL_APi_Url);
     return teamData;
  }
  async findTeamByName(teamName) {
    return leagueModel.findOne({ team_name: teamName });
  }

  async updateTeam(teamName, data) {
    return leagueModel.updateOne({ team_name: teamName }, { $set: data });
  }

  async createTeam(data) {
    return leagueModel.create(data);
  }
}

export default new GlobalService();