"use strict";
class MailSender {
    constructor() {
      // Create a transporter using SMTP
      this.transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'your-email@gmail.com',
          pass: 'your-email-password',
        },
      });
    }
  
    async sendMail(to, subject, text) {
      // Define email options
      const mailOptions = {
        from: 'your-email@gmail.com',
        to,
        subject,
        text,
      };
  
      try {
        // Send email
        const info = await this.transporter.sendMail(mailOptions);
        console.log('Email sent:', info.response);
        return info;
      } catch (error) {
        console.error('Error sending email:', error);
        throw new Error('Failed to send email');
      }
    }
  }
  export default MailSender;