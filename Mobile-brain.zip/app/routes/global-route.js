"use strict";
//global-route.js
import configApi from '../../config/configApi.json' assert { type: 'json' };
import globalController from '../applayer/controller/global/globalController.js';
const { apiPrefix } = configApi;
export default function setupGlobalRoutes(app) {
  app.get(`${apiPrefix}/get/team`, globalController.getTeam);
}
