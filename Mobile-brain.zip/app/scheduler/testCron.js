// testCron.js
"use strict";
import cron from 'cron';
import apiUrlConfig from '../../config/configApi.json' assert { type: 'json' };
import globalHelper from '../helper/globalHelper.js';
import Logger from '../util/logger.js'; 
import container from '../applayer/di/container.js';

class testCron {
  constructor() {
    this.helper = new globalHelper();
    this.globalService = container.resolve('globalService');
    this.logger = new Logger();
  }

  async updateOrInsertTeam() {
    try {
      const teamData = await this.helper.fetchData(apiUrlConfig.PL_APi_Url);
       this.logger.logInfo('Fetched team data', teamData);
      for (const team of teamData) {
        const existingTeam = await this.globalService.findTeamByName(team.team_name);
        if (existingTeam) {
           this.logger.logInfo('Updating existing team', { team_name: team.team_name });
          await this.globalService.updateTeam(team.team_name, team);
        } else {
          console.log("createTeam");
          await this.globalService.createTeam(team);
        }
      }
    } catch (error) {
      console.error('Error updating database:', error.message);
      this.logger.error('Error updating database', error);
    }
  }

  async insertOrUpdateTeamCron() {
    const dailyJob = new cron.CronJob('*/1 * * * *', this.updateOrInsertTeam.bind(this), null, true);
    dailyJob.start();
  }
}

export default testCron;
