"use strict";
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import dotenv from 'dotenv';
import express from 'express';
import path from 'path';
import cookieParser from 'cookie-parser';
import logger from 'morgan';
import helmet from 'helmet';
import cors from 'cors';
import connectToMongoDB from './config/db.js';
import globalRoutes from './app/routes/global-route.js';
dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const { PORT } = process.env;
const app = express();
connectToMongoDB();
app.use(helmet());
app.use(cors());
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));   
app.get('/', (req, res) => {
  res.send('API running on port: 8080!');
});
// Import the background processes file
// import './app/scheduler/backgroundProcesses.js'; 
globalRoutes(app);
//server start
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
