"use strict";
import configApi from '../../../config/configApi.js';
import verifyTokenMiddleware from '../../middleware/auth/verifyTokenMiddleware.js';
 //all routes
const { apiPrefix } = configApi;
export default function setupGlobalRoutes(app) {
     
}
