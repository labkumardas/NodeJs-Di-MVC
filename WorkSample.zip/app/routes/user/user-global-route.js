"use strict";
import configApi from '../../../config/configApi.js';
  //all routes
const { apiPrefixUser } = configApi;
export default function setupGlobalRoutes(app) {
     
}
